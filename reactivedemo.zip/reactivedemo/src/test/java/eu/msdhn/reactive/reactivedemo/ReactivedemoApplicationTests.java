package eu.msdhn.reactive.reactivedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactivedemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
