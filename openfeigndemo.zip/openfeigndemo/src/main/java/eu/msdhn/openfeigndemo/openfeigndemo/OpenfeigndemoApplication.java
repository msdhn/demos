package eu.msdhn.openfeigndemo.openfeigndemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OpenfeigndemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(OpenfeigndemoApplication.class, args);
	}

}
