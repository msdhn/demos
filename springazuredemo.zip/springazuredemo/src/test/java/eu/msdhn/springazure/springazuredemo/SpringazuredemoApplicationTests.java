package eu.msdhn.springazure.springazuredemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringazuredemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
