package eu.msdhn.openfeigndemo.openfeigndemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpenfeigndemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
